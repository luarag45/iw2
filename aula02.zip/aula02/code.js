//console.log("Olá JS")

let c1 = "roxo"
let c2 = "azul"
let c3 = "branco"
let c4 = "preto"
let c5 = "purpura"

//Array - vetor
const dados = [c1,c2,c3,c4,c5]

let cor = "roxo"

for(let i=0;i<dados.length;i++){

    if(cor == dados[i]){
        console.log("Encontrado! " + i)
        break
    } else {
        console.log("Não encontrado")
    }

    

}

