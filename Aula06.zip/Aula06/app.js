function dados(){
    const ds = [
                {id:1,login:"Luara",senha:"1234",email:"Luara@gmail.com"},
                {id:2,login:"Luana",senha:"4321",email:"Luana@gmail.com"},
                {id:3,login:"Laura",senha:"2134",email:"Laura@gmail.com"}
                ]
    return ds
}

function login(user,password){

    const usuarios = dados()

for(let i=0;i<usuarios.length;i++)

    if(user == usuarios[i].login && password == usuarios[i].senha){
        console.log("Você Logou")
        break
    }
}

function logar(){
    let lg = document.getElementById("login").value
    let sn = document.getElementById("senha").value

    login(lg,sn)
}